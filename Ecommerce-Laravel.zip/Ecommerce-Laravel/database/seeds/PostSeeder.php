<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PostSeeder extends Seeder
{
    public function run()
    {
        $posts = [
            [
                'title' => 'Welcome to Our Store',
                'slug' => 'welcome-to-our-store',
                'summary' => 'Discover the latest trends and offers.',
                'description' => 'We bring you curated collections and exclusive deals every week.',
                'quote' => null,
                'photo' => '/photos/1/blog3.jpg',
                'tags' => 'store,news',
                'post_cat_id' => null,
                'post_tag_id' => null,
                'added_by' => DB::table('users')->where('email','admin@mail.com')->value('id'),
                'status' => 'active',
            ],
            [
                'title' => 'Summer Collection Drop',
                'slug' => 'summer-collection-drop',
                'summary' => 'New arrivals for the summer season.',
                'description' => 'Check out our light and breezy collection for the sunny days.',
                'quote' => null,
                'photo' => '/photos/1/blog3.jpg',
                'tags' => 'summer,collection',
                'post_cat_id' => null,
                'post_tag_id' => null,
                'added_by' => DB::table('users')->where('email','admin@mail.com')->value('id'),
                'status' => 'active',
            ],
            [
                'title' => 'Top Picks This Week',
                'slug' => 'top-picks-this-week',
                'summary' => 'Handpicked items you shouldn’t miss.',
                'description' => 'Our editors selected their favorite products for you.',
                'quote' => null,
                'photo' => '/photos/1/blog3.jpg',
                'tags' => 'featured,picks',
                'post_cat_id' => null,
                'post_tag_id' => null,
                'added_by' => DB::table('users')->where('email','admin@mail.com')->value('id'),
                'status' => 'active',
            ],
        ];

        foreach ($posts as $post) {
            DB::table('posts')->updateOrInsert(
                ['slug' => $post['slug']],
                $post + ['created_at' => now(), 'updated_at' => now()]
            );
        }
    }
}
