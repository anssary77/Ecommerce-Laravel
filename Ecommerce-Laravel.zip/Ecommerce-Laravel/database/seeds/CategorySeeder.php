<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    public function run()
    {
        $categories = [
            [
                'title' => 'Men',
                'slug' => 'men',
                'summary' => 'Men apparel and accessories',
                'photo' => '/photos/1/Category/mini-banner1.jpg',
                'is_parent' => 1,
                'parent_id' => null,
                'status' => 'active',
            ],
            [
                'title' => 'Women',
                'slug' => 'women',
                'summary' => 'Women fashion and beauty',
                'photo' => '/photos/1/Category/mini-banner2.jpg',
                'is_parent' => 1,
                'parent_id' => null,
                'status' => 'active',
            ],
            [
                'title' => 'Kids',
                'slug' => 'kids',
                'summary' => 'Kids clothing and toys',
                'photo' => '/photos/1/Category/mini-banner3.jpg',
                'is_parent' => 1,
                'parent_id' => null,
                'status' => 'active',
            ],
        ];

        foreach ($categories as $cat) {
            DB::table('categories')->updateOrInsert(
                ['slug' => $cat['slug']],
                $cat + ['created_at' => now(), 'updated_at' => now()]
            );
        }
    }
}
