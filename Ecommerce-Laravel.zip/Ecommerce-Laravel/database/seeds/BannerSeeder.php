<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BannerSeeder extends Seeder
{
    public function run()
    {
        $banners = [
            [
                'title' => 'Summer Sale',
                'slug' => 'summer-sale',
                'photo' => '/photos/1/Banner/banner-01.jpg',
                'description' => 'Up to 50% off on selected items',
                'status' => 'active',
            ],
            [
                'title' => 'New Arrivals',
                'slug' => 'new-arrivals',
                'photo' => '/photos/1/Banner/banner-06.jpg',
                'description' => 'Check out the latest products',
                'status' => 'active',
            ],
            [
                'title' => 'Best Deals',
                'slug' => 'best-deals',
                'photo' => '/photos/1/Banner/banner-07.jpg',
                'description' => 'Don’t miss these discounts',
                'status' => 'active',
            ],
        ];

        foreach ($banners as $banner) {
            DB::table('banners')->updateOrInsert(
                ['slug' => $banner['slug']],
                $banner + ['created_at' => now(), 'updated_at' => now()]
            );
        }
    }
}
