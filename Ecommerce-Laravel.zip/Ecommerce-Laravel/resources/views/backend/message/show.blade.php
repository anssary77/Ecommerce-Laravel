@extends('backend.layouts.master')
@section('title',__('backend.message.show'))
@section('main-content')
<div class="card">
  <h5 class="card-header">{{__('backend.message.show')}}</h5>
  <div class="card-body">
    @if($message)
        @if($message->photo)
        <img src="{{$message->photo}}" class="rounded-circle " style="margin-left:44%;">
        @else
        <img src="{{asset('backend/img/avatar.png')}}" class="rounded-circle " style="margin-left:44%;">
        @endif
        <div class="py-4">{{__('backend.message.fields.from')}}:<br>
           {{__('backend.message.fields.name')}} :{{$message->name}}<br>
           {{__('backend.message.fields.email')}} :{{$message->email}}<br>
           {{__('backend.message.fields.phone')}} :{{$message->phone}}
        </div>
        <hr/>
  <h5 class="text-center" style="text-decoration:underline"><strong>{{__('backend.message.fields.subject')}} :</strong> {{$message->subject}}</h5>
        <p class="py-5">{{$message->message}}</p>

    @endif

  </div>
</div>
@endsection
