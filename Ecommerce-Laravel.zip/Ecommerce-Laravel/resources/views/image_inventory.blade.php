<!doctype html>
<html lang="ar">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>فهرس الصور</title>
    <link rel="stylesheet" href="/frontend/css/bootstrap.css">
    <style>
        body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif;padding:20px}
        .header{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px}
        .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
        .card{border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;background:#fff}
        .thumb{aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;background:#f9fafb}
        .thumb img{max-width:100%;max-height:100%;object-fit:contain}
        .path{padding:10px;font-size:12px;direction:ltr;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border-top:1px solid #e5e7eb;background:#fafafa}
        .count{margin-inline-start:auto}
        .input{padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;min-width:280px}
        .btn{padding:8px 12px;border:1px solid #374151;border-radius:6px;background:#111827;color:#fff}
        .toolbar{display:flex;gap:8px;align-items:center}
    </style>
</head>
<body>
    <div class="header">
        <div class="toolbar">
            <form method="get">
                <input class="input" type="text" name="ext" value="{{ implode(',', $extensions) }}" placeholder="مثال: jpg,png,gif">
                <button class="btn" type="submit">تصفية بالامتدادات</button>
            </form>
        </div>
        <div class="count">الإجمالي: {{ count($images) }}</div>
    </div>
    <div class="grid">
        @foreach($images as $src)
            <div class="card">
                <div class="thumb">
                    <img src="{{ $src }}" alt="image">
                </div>
                <div class="path">src="{{ $src }}"</div>
            </div>
        @endforeach
    </div>
</body>
</html>