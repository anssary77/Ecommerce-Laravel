@extends('frontend.layouts.master')

@section('title','Ecommerce Laravel || Order Track Page')

@section('main-content')
    <!-- Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="bread-inner">
                        <ul class="bread-list">
                            <li><a href="{{route('home')}}">Home<i class="ti-arrow-right"></i></a></li>
                            <li class="active"><a href="javascript:void(0);">Order Track</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->
<section class="tracking_box_area section_gap py-5">
    <div class="container">
        <div class="tracking_box_inner">
            <p>To track your order please enter your Order ID in the box below and click the "Track" button. This was given
                to you on your receipt and in the confirmation email you should have received or you can get your order id from your user dashboard.</p>
            <form class="row tracking_form my-4" action="{{route('product.track.order')}}" method="post" novalidate="novalidate">
              @csrf
                <div class="col-md-8 form-group">
                    <input type="text" class="form-control p-2"  name="order_number" placeholder="Enter your order number" value="{{old('order_number')}}">
                </div>
                <div class="col-md-8 form-group">
                    <button type="submit" value="submit" class="btn submit_btn">Track Order</button>
                </div>
            </form>

            @if(isset($statusMessage))
                <div class="row">
                    <div class="col-md-8">
                        <div class="alert alert-{{$statusType ?? 'info'}}" role="alert">
                            {{$statusMessage}}
                        </div>
                    </div>
                </div>
            @endif

            @if(isset($order) && $order)
                <div class="order-status card mt-3">
                    <div class="card-body">
                        <h5 class="card-title">Order #{{$order->order_number}}</h5>
                        <p class="mb-1"><strong>Status:</strong> <span class="badge badge-{{$statusType == 'success' ? 'success' : ($statusType == 'warning' ? 'warning' : ($statusType == 'danger' ? 'danger' : 'info'))}}">{{$order->status}}</span></p>
                        <p class="mb-1"><strong>Placed on:</strong> {{$order->created_at->format('D d M, Y g:i A')}}</p>
                        <p class="mb-1"><strong>Total Amount:</strong> ${{number_format($order->total_amount,2)}}</p>
                        <p class="mb-1"><strong>Payment Method:</strong> {{strtoupper($order->payment_method)}}</p>
                        <p class="mb-0"><strong>Delivery Address:</strong> {{$order->address1}}, {{$order->address2}}</p>
                    </div>
                </div>
            @endif
        </div>
    </div>
</section>
@endsection
