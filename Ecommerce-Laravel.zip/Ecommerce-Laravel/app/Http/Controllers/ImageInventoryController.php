<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ImageInventoryController extends Controller
{
    public function index(Request $request)
    {
        $extParam = $request->query('ext');
        $extensions = $extParam ? collect(explode(',', $extParam))->map(function ($e) {
            return strtolower(trim($e));
        })->filter()->values()->all() : ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'bmp', 'tiff'];

        $paths = [];
        foreach ([$this->scanPublic($extensions), $this->scanStorage($extensions)] as $list) {
            $paths = array_merge($paths, $list);
        }
        sort($paths);

        return view('image_inventory', [
            'images' => $paths,
            'extensions' => $extensions,
        ]);
    }

    private function scanPublic(array $extensions): array
    {
        $dir = public_path();
        return $this->scanDir($dir, $extensions, function ($file) use ($dir) {
            return '/' . ltrim(str_replace($dir, '', $file), '/');
        });
    }

    private function scanStorage(array $extensions): array
    {
        $dir = storage_path('app/public');
        return $this->scanDir($dir, $extensions, function ($file) use ($dir) {
            return '/storage/' . ltrim(str_replace($dir, '', $file), '/');
        });
    }

    private function scanDir(string $dir, array $extensions, callable $toWebPath): array
    {
        if (!is_dir($dir)) {
            return [];
        }
        $result = [];
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $fileinfo) {
            if (!$fileinfo->isFile()) {
                continue;
            }
            $ext = strtolower($fileinfo->getExtension());
            if (in_array($ext, $extensions, true)) {
                $result[] = $toWebPath($fileinfo->getPathname());
            }
        }
        return $result;
    }
}

