<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $targetDb = env('DB_DATABASE_MYSQL', env('DB_DATABASE', 'ecommercealaravel'));
        config(['database.default' => 'mysql']);
        Schema::defaultStringLength(191);

        try {
            $mysql = config('database.connections.mysql');
            $setup = $mysql;
            $setup['database'] = null;
            config(['database.connections.mysql_setup' => $setup]);
            DB::connection('mysql_setup')->statement("CREATE DATABASE IF NOT EXISTS `{$targetDb}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            config(['database.connections.mysql.database' => $targetDb]);
            DB::purge('mysql');
            DB::reconnect('mysql');
        } catch (\Throwable $e) {
            // silently ignore if creation fails (e.g., mysql client not available or permissions)
        }
    }
}
