<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class UpdateSettings extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'settings:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update settings data in database';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $data = [
            'address' => 'القاهرة، محافظة القاهرة، مصر',
            'email' => 'AnSSarY',
            'phone' => '1234567777',
            'logo' => '/images/logo.svg',
        ];

        $updated = DB::table('settings')
            ->where('id', 1)
            ->update($data);

        if ($updated) {
            $this->info('Settings updated successfully!');
            $this->info('Address: ' . $data['address']);
            $this->info('Email: ' . $data['email']);
            $this->info('Phone: ' . $data['phone']);
            $this->info('Logo: ' . $data['logo']);
        } else {
            $this->error('Failed to update settings. Make sure settings record exists.');
        }

        return Command::SUCCESS;
    }
}
