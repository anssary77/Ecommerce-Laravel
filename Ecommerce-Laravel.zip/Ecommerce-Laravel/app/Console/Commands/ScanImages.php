<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Finder\Finder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class ScanImages extends Command
{
    protected $signature = 'scan:images {--fix} {--report=storage/app/image-scan-report.json}';
    protected $description = 'Scan project for image references, ensure existence, and report';

    public function handle()
    {
        $root = base_path();
        $publicRoot = public_path();
        $ignore = ['vendor', 'storage', '.git', 'node_modules'];
        $exts = ['php','blade.php','js','ts','tsx','css','scss','sass','less','html','htm','json','md','xml','yml','yaml'];
        $imgExt = ['png','jpg','jpeg','gif','webp','svg'];
        $finder = new Finder();
        $finder->files()->in($root)->name(array_map(function($e){return '*.'. $e;}, $exts));
        foreach ($ignore as $ig) { $finder->exclude($ig); }

        $refs = [];
        foreach ($finder as $file) {
            $path = $file->getRealPath();
            $content = $file->getContents();
            $patterns = [
                '/src\s*=\s*["\\\']([^"\\\']+\.(?:png|jpe?g|gif|webp|svg))["\\\']/i',
                '/href\s*=\s*["\\\']([^"\\\']+\.(?:png|jpe?g|gif|webp|svg))["\\\']/i',
                '/url\(\s*["\\\']?([^"\)\\\']+\.(?:png|jpe?g|gif|webp|svg))["\\\']?\s*\)/i',
                '/asset\(\s*["\\\']([^"\\\']+\.(?:png|jpe?g|gif|webp|svg))["\\\']\s*\)/i',
                '/[^"\'>\s]+\.(?:png|jpe?g|gif|webp|svg)/i',
            ];
            foreach ($patterns as $rx) {
                if (preg_match_all($rx, $content, $m)) {
                    $group = isset($m[1]) ? $m[1] : $m[0];
                    foreach ($group as $ref) {
                        $refs[$ref] = true;
                    }
                }
            }
        }

        $images = array_keys($refs);
        $report = [];
        foreach ($images as $ref) {
            if (Str::startsWith($ref, ['http://','https://','data:'])) {
                $report[] = ['reference' => $ref, 'resolved_path' => null, 'status' => 'external'];
                continue;
            }
            $resolved = null;
            $candidatePublic = $this->normalizePath($publicRoot, $ref);
            $candidateLocal = $this->normalizePath($root, $ref);
            if (file_exists($candidatePublic)) { $resolved = $candidatePublic; }
            elseif (file_exists($candidateLocal)) { $resolved = $candidateLocal; }
            else { $resolved = $candidatePublic; }

            $exists = file_exists($resolved);
            if (!$exists && $this->option('fix')) {
                $this->ensureDir(dirname($resolved));
                $ext = strtolower(pathinfo($resolved, PATHINFO_EXTENSION));
                if (in_array($ext, ['png','jpg','jpeg','gif','webp'])) {
                    try {
                        $im = imagecreatetruecolor(800, 450);
                        $bg = imagecolorallocate($im, 221, 221, 221);
                        $fg = imagecolorallocate($im, 51, 51, 51);
                        imagefilledrectangle($im, 0, 0, 800, 450, $bg);
                        $text = 'TEMP IMAGE GENERATED: '.basename($resolved);
                        imagestring($im, 5, 100, 220, $text, $fg);
                        if ($ext === 'jpg' || $ext === 'jpeg') { imagejpeg($im, $resolved, 80); }
                        elseif ($ext === 'png') { imagepng($im, $resolved, 6); }
                        elseif ($ext === 'gif') { imagegif($im, $resolved); }
                        elseif ($ext === 'webp' && function_exists('imagewebp')) { imagewebp($im, $resolved, 80); }
                        imagedestroy($im);
                    } catch (\Throwable $e) {
                        file_put_contents($resolved, 'TEMP IMAGE GENERATED');
                    }
                } elseif ($ext === 'svg') {
                    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450"><rect width="100%" height="100%" fill="#ddd"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="24" fill="#333">TEMP IMAGE GENERATED: '.htmlspecialchars(basename($resolved), ENT_QUOTES).'</text></svg>';
                    file_put_contents($resolved, $svg);
                } else {
                    file_put_contents($resolved, 'TEMP IMAGE GENERATED');
                }
                $exists = file_exists($resolved);
            }

            $report[] = [
                'reference' => $ref,
                'resolved_path' => $exists ? $resolved : $resolved,
                'status' => $exists ? 'exists' : 'created',
            ];
        }

        $dest = base_path($this->option('report'));
        $this->ensureDir(dirname($dest));
        file_put_contents($dest, json_encode($report, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
        $this->info('Image scan completed. Report: '.$dest);
        return 0;
    }

    protected function normalizePath($base, $ref)
    {
        $ref = ltrim($ref, '/');
        return rtrim($base, DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.str_replace(['\\','/'], DIRECTORY_SEPARATOR, $ref);
    }

    protected function ensureDir($dir)
    {
        if (!is_dir($dir)) { mkdir($dir, 0777, true); }
    }
}
